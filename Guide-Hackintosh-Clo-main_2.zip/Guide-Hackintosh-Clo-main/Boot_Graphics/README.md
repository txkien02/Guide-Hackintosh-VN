# Boot Graphics
![BootGraphics](https://user-images.githubusercontent.com/76865553/136703531-d311f0d3-d296-4120-b31c-934ca9bea353.jpeg)
### DefaultBackground Color
Màu nền (trong HEX) cho menu khởi động macOS.

### EFILoginHiDPI
Đặt thành `1` để bật đầu ra HiDPI cho menu khởi động macOS.

### flagstate
> Không có mục nhập trong thủ công

### UIScale
Đặt hệ số tỷ lệ cho kích thước của menu khởi động macOS. Đặt thành `2` cho màn hình 4k.